// let a = 10;
// {
//     let a =20;
//     console.log("inside:", a);
// }
// console.log("outside:", a);

// datatypes
// data ka type

// primitives -> aisi saari values jinko copy karne par tumhe ek real copy mil jaaye
// string, number, boolean, null, undefined, symbol, bigint
// ex:
// let a = 12;
// let b = a;
// console.log(b)
// a = a + 2;
// console.log(a)
// console.log(b)

// strings : - ' ' (single quotes)
//         : - " " (double quotes)
//         : - ` ` (backticks)
// number : - 12(number)
 //   : - 12.5(number)
// null - ka matlb hai apne jaan boojh kar koi value nahi di
// // undefined ka matlab ki aapne ek variable banaya aur usey value nahi di to jo value by default mili wo hai undefined
// // future.mein.hum koi libraries use karege ab is case mein un libraries
// mein kai baar kuchh fields hoti hai jinse similar hum bhi banaa dete hai
// aur galti se humaari banaai hui fields us library ki original fields ko
// change kar deta hai
// // symbol -> unique immutable value
// future mein hum koi libraries use karege ab is case mein un libraries
// mein kai baar kuchh fields hoti hai jinse similar hum bhi banaa dete hai
// aur galti se humaari banaai hui fields us library ki original fields ko
// change kar deta hai

// Number.MAX_SAFE_INTIGER

// bigint
// let a = 9007199254740991n;
// console.log(typeof"a");
// console.log(a + 3n);
// console.log(a + 2n);
// console.log(a + 1n);



// reference -> inko copy karne par real copy nahi milegi but aapko reference milega parent ka
// arrays, objects, functions -> [] {} ()
//   ex: 
// let a = [1,2,3]
// let b = a;
// b.pop();

// console.log(a)


// // Dynamic typing -> js mein static typing nani hai and yana par hal
// dynamic typing jiska matlab hai aap data ko change kr skte ho kyukli yaha
// par dynamic data types hai

// let a = 12;
// a = true;

// typeof quirks (e.g., typeof null === 'object')
// // Type coercion ( == VS === )
// Truthy vs falsy values

// type coercion -> concept jismein aapka ek type automatically convert
// hojaayega

// "5" + 1 = 51 (concatination)
// "5" - 1 = 4


// Truthy vs falsy values

// 0 false "" null undefined NaN document.all -> false
// rest all -> True
// !! 0
// !!""
// false
// !!NaN
// false
// !!null
// false
// !!document. all
// false
// let a = undefined
// console.log(!!a);
// false

// Practice

// Predict the result: true + false, null + 1, 5 + "5", !!undefined

// let a = true + false
// console.log(a)
// ans = 1(true)

// let b = null + 1
// console.log(b)
// ans = 1(true)

// let c = 5 + "5"
// console.log(!!c)
// ans = 55(true)

// // let a = undefined
// console.log(!!a);
// false

// console.log(typeof NaN) === 'number' // true
// Nan type is number because it is a failed number of operation and whenever failed operation is performed then its tupe is number.

// let x;
// console.log(x); (undefined)
// let y = null;
// console.log(y);  (null)

// operators
// Arithmetic, comparison, logical, assignment, unary, ternary

// + - * / % **   arithmetic operator 
// ex: 1+2=3 & "1"+2=12, 5-2= 3, 5*2=10, 10/5=2, 10%5=2, 2**3=8

// comparision
// = == === 
// ex: =(usetoputvalue), ==(comparision/doesn't check the type), ===(completely checks the lhs$rhs)
// 12 == 13 false
// 12=="12" true
// 12==="12" false

// < > <= >= ! != !==
// ex: 
// 12 != 13 true
// 12 != "12" false
// 12 !== "12" true
// 12 > 11 true
// 12 > 12 false
// 12>= 12 true

// assingnment operator
// let a = 12;
// a += 3;         -> a = a + 3      -> a = 12 + 3
// a -= 11;        -> a = a - 11     -> a = 15 - 11
// a *= 2; 1       -> a = a * 2         .....
// a /= 2;         -> a = a / 2         .....
// a %= 3;         -> a = a % 3         .....

//  &&    (and operator)
// true && true     -> true
// 12>11 && 11>10   
// false && true    -> false
// true && false    -> false
// false && false   -> false

//  ||   (or operator)
// // true || true     -> true
// 12>11 || 11>10   
// false || true    -> true
// true || false    -> true
// false || false   -> false

//  ! (not operator)
// 11 = true
// !11 = false
// !!11 = true


// unary operator
// + - ! typeof ++ --
// "5"(string) ->  +"5"=5(number)
// "viquar"(string) -> +"viquar"= viquar(NaN)
// "5"(string) ->  -"5"=-5(number)
//  typeof 12 -> 'number'
// typeof "12" -> 'string'

//  let a = 2;
// console.log(a);
// a++;
// console.log(a);
// console.log(a++ + a)

// let a = 5;
// a--;
// console.log(a);
// console.log(a-- - a);


// ? : (ternary operator)
// let c = 12 > 13 ? console.log(true) : console.log(false);


// typeof and instanceof
// typeof (works with primitive values)
// console.log(typeof null)
// console.log(typeof [])
// console.log(typeof {})
// console.log(typeof function(){})
// console.log(typeof NaN)

//  instanceof (only works with reference values like array object function)
// let a = [1, 2, 3];
// console.log(a instanceof Array);
// let b = {};
// console.log(b instanceof Object);
// console.log(b instanceof Array);

// let x = 10;
// let y = 20;

// if (x > 5 && y < 25){
//     console.log("A");
// } else {
//     console.log("B");
// }

