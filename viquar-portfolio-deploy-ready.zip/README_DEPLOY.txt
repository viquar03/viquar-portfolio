VIQUAR PORTFOLIO — DEPLOYMENT PACKAGE

This folder is prepared as a static website with index.html at the repository root.

GITHUB
1. Create a new public repository named viquar-portfolio.
2. Upload the CONTENTS of this folder (index.html, Viquarsportfolio.css, images, etc.)
   to the repository root, not the containing folder.
3. Commit the upload to the main branch.

VERCEL
1. Open https://vercel.com/new and import the viquar-portfolio repository.
2. Select Framework Preset: Other.
3. Leave Build Command empty.
4. Set Output Directory to . (or leave the default if Vercel detects the static root).
5. Deploy. Vercel will generate the public HTTPS URL.

VERIFY
- The homepage is index.html.
- The stylesheet and image assets are referenced with relative paths.
- Add the final live URL to the resume and LinkedIn only after the deployment succeeds.

Note: This package is prepared for deployment; it has NOT been uploaded to GitHub or deployed to Vercel.
